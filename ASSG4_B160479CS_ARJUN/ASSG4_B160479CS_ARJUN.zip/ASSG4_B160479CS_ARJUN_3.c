#include <stdio.h>
#include <stdlib.h>

struct unRankedNode
{
	int data;
	struct unRankedNode *parent;
};

struct rankedNode
{
	int data;
	int rank;
	struct rankedNode *parent;
};

struct unRankedUnCompressedS
{
	struct unRankedNode *head;
};

struct rankedUnCompressedS
{
	struct rankedNode *head;	
};

struct rankedCompressedS
{
	struct rankedNode *head;
};

struct unRankedCompressedS
{
	struct unRankedNode *head;
};


int main()
{
	
	return 0;
}